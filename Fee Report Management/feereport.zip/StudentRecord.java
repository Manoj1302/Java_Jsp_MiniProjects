package feereport;

public class StudentRecord {
	public String REGD_ID;
	public String STUD_NAME;
	public String MOBILE;
	public String EMAIL;
	public String DEPT;
	public int FEE;
	public int PAID;
	public int DUE;
	public String ADDRESS;
	public String CITY;
	public String STATE;
	public String COUNTRY;
	public String REGISTER_DATE;

	public String getREGD_ID() {
		return REGD_ID;
	}

	public void setREGD_ID(String rEGD_ID) {
		REGD_ID = rEGD_ID;
	}

	public String getSTUD_NAME() {
		return STUD_NAME;
	}

	public void setSTUD_NAME(String sTUD_NAME) {
		STUD_NAME = sTUD_NAME;
	}

	public String getMOBILE() {
		return MOBILE;
	}

	public void setMOBILE(String mOBILE) {
		MOBILE = mOBILE;
	}

	public String getEMAIL() {
		return EMAIL;
	}

	public void setEMAIL(String eMAIL) {
		EMAIL = eMAIL;
	}

	public String getDEPT() {
		return DEPT;
	}

	public void setDEPT(String dEPT) {
		DEPT = dEPT;
	}

	public int getFEE() {
		return FEE;
	}

	public void setFEE(int fEE) {
		FEE = fEE;
	}

	public int getPAID() {
		return PAID;
	}

	public void setPAID(int pAID) {
		PAID = pAID;
	}

	public int getDUE() {
		return DUE;
	}

	public void setDUE(int dUE) {
		DUE = dUE;
	}

	public String getADDRESS() {
		return ADDRESS;
	}

	public void setADDRESS(String aDDRESS) {
		ADDRESS = aDDRESS;
	}

	public String getCITY() {
		return CITY;
	}

	public void setCITY(String cITY) {
		CITY = cITY;
	}

	public String getSTATE() {
		return STATE;
	}

	public void setSTATE(String sTATE) {
		STATE = sTATE;
	}

	public String getCOUNTRY() {
		return COUNTRY;
	}

	public void setCOUNTRY(String cOUNTRY) {
		COUNTRY = cOUNTRY;
	}

	public String getREGISTER_DATE() {
		return REGISTER_DATE;
	}

	public void setREGISTER_DATE(String rEGISTER_DATE) {
		REGISTER_DATE = rEGISTER_DATE;
	}

}
